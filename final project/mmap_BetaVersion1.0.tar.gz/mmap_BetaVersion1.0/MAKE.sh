 icc  -O3 -o run  vcv-mmap-matmat-mult-july02.c -openmp -std=c99 -lm -mkl


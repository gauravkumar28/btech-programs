icc  -O3 -o run vcv-mmap-matmat-mult-july03.c -openmp -mmic -std=c99  -L/opt/intel/lib/mic -Wno-unknown-pragmas  -lm -mkl


icc  -O3 -o run vcv-mmap-matmat-mult-july03.c -openmp -std=c99 -lm -mkl

